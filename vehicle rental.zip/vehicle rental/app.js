
let discount = 0;

function applyCoupon(){

let code =
document.getElementById("coupon").value;

if(code==="SAVE20"){
discount=20;
alert("20% Discount Applied");
}
else{
alert("Invalid Coupon");
}
}

function addNotification(msg){

let div=document.createElement("div");

div.className="notice";

div.innerHTML=
new Date().toLocaleTimeString()
+" - "+msg;

document
.getElementById("notifications")
.prepend(div);
}

function submitReview(){

let name =
document.getElementById("reviewName").value;

let rating =
document.getElementById("reviewRating").value;

let text =
document.getElementById("reviewText").value;

let card=document.createElement("div");

card.className="review-card";

card.innerHTML=
`
<b>${name}</b>
⭐ ${rating}<br>
${text}
`;

document
.getElementById("reviews")
.prepend(card);
}
addNotification("System Started");
let fare = km * selectedPrice;

if(discount>0){
fare = fare - (fare*discount/100);
}

document
.getElementById("completed")
.innerHTML = totalBookings;

addNotification(
vehicle +
" booked successfully"
);
function sendMessage(){

let name =
document.getElementById("contactName").value;

if(name===""){
alert("Enter Name");
return;
}

alert("Message Sent Successfully!");

addNotification(
"New Contact Message Received"
);
}

function bookVehicle(){

let customer =
document.getElementById("name").value;

let vehicle =
document.getElementById("vehicle").value;

let km =
parseFloat(document.getElementById("distance").value);

let payment =
document.getElementById("paymentMethod").value;

if(!customer || !vehicle || !km || !payment){
    alert("Please fill all details");
    return;
}

let fare = km * selectedPrice;

document.getElementById("fare").innerHTML =
"Estimated Fare: ₹" + fare;

document.getElementById("paymentStatus").innerHTML =
"✅ Payment Method Selected: " + payment;

totalRevenue += fare;
totalBookings++;

document.getElementById("revenue").innerHTML =
"₹" + totalRevenue;

document.getElementById("rides").innerHTML =
totalBookings;

let booking = document.createElement("div");

booking.className = "booking-item";

booking.innerHTML = `
<b>${customer}</b><br>
Vehicle: ${vehicle}<br>
Distance: ${km} KM<br>
Fare: ₹${fare}<br>
Payment: ${payment}<br>
Status: Paid
`;

document.getElementById("history")
.prepend(booking);

alert("🎉 Booking Confirmed!");
}

function applyCoupon(){

    let code =
    document.getElementById("coupon").value;

    if(code==="SAVE10"){
        discount = 10;
        alert("10% Discount Applied");
    }

    else if(code==="SAVE20"){
        discount = 20;
        alert("20% Discount Applied");
    }

    else{
        alert("Invalid Coupon");
    }
}
/*payment history */
let paymentRecords = [];

function processPayment(){

    const paymentMethod =
    document.getElementById(
    "paymentMethod"
    ).value;

    if(paymentMethod === ""){
        alert(
        "Please select a payment method"
        );
        return;
    }

    const vehicle =
    document.getElementById(
    "vehicle"
    ).value;

    const distance =
    document.getElementById(
    "distance"
    ).value;

    const amount =
    distance * selectedPrice;

    const payment = {

        id:
        "TXN" +
        Date.now(),

        vehicle,

        amount,

        paymentMethod,

        date:
        new Date()
        .toLocaleString(),

        status:
        "Success"
    };

    paymentRecords.push(
    payment
    );

    document.getElementById(
    "paymentStatus"
    ).innerHTML =
    "✅ Payment Successful";

    updatePaymentHistory();
}
/*display payment */
function updatePaymentHistory(){

    const history =
    document.getElementById(
    "paymentHistory"
    );

    history.innerHTML = "";

    paymentRecords
    .slice()
    .reverse()
    .forEach(payment => {

        history.innerHTML += `
        <div class="payment-card">

            <b>Transaction:</b>
            ${payment.id}<br>

            <b>Vehicle:</b>
            ${payment.vehicle}<br>

            <b>Amount:</b>
            ₹${payment.amount}<br>

            <b>Method:</b>
            ${payment.paymentMethod}<br>

            <b>Status:</b>
            ${payment.status}<br>

            <b>Date:</b>
            ${payment.date}

        </div>
        `;
    });
}
function savePayments(){

localStorage.setItem(
"payments",
JSON.stringify(paymentRecords)
);
}

function loadPayments(){

const data =
localStorage.getItem(
"payments"
);

if(data){

paymentRecords =
JSON.parse(data);

updatePaymentHistory();
}
}

loadPayments();
/*special event */
function bookEvent(){

    const eventType =
    document.getElementById("eventType").value;

    const eventDate =
    document.getElementById("eventDate").value;

    const hours =
    Number(
    document.getElementById("eventHours").value
    );

    if(!eventType || !eventDate || !hours){
        alert("Please fill all event details");
        return;
    }

    let eventPrice = 0;

    switch(eventType){

        case "Wedding":
            eventPrice = 3000;
            break;

        case "Birthday":
            eventPrice = 1500;
            break;

        case "Corporate":
            eventPrice = 2500;
            break;

        case "Airport":
            eventPrice = 1200;
            break;

        case "VIP":
            eventPrice = 5000;
            break;
    }

    const total =
    eventPrice * hours;

    document.getElementById(
    "eventResult"
    ).innerHTML = `
    <h3>Booking Confirmed ✅</h3>
    Event: ${eventType}<br>
    Date: ${eventDate}<br>
    Duration: ${hours} Hours<br>
    Total Cost: ₹${total}
    `;
}


const express = require('express');
const app = express();
const PORT = 3000;

app.use(express.json());

// ─── Pricing Table ───────────────────────────────────────────────
const EVENT_PRICING = {
  conference: 150,
  wedding:    300,
  birthday:   100,
  corporate:  200,
  concert:    250,
};

// ─── Frontend (inline HTML) ──────────────────────────────────────
app.get('/', (req, res) => {
  res.send(`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Event Booking</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f0f4f8;
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .card {
      background: #fff;
      border-radius: 12px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.1);
      padding: 2rem;
      width: 100%;
      max-width: 460px;
    }

    h2 { font-size: 1.5rem; margin-bottom: 1.5rem; color: #1a202c; }

    label {
      display: block;
      font-size: 0.875rem;
      font-weight: 600;
      color: #4a5568;
      margin-bottom: 0.25rem;
    }

    select, input {
      width: 100%;
      padding: 0.6rem 0.75rem;
      border: 1px solid #cbd5e0;
      border-radius: 8px;
      font-size: 1rem;
      margin-bottom: 1rem;
      outline: none;
      transition: border-color 0.2s;
    }

    select:focus, input:focus { border-color: #667eea; }

    button {
      width: 100%;
      padding: 0.75rem;
      background: #667eea;
      color: #fff;
      font-size: 1rem;
      font-weight: 600;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      transition: background 0.2s;
    }

    button:hover    { background: #5a67d8; }
    button:disabled { background: #a0aec0; cursor: not-allowed; }

    #eventResult {
      margin-top: 1.5rem;
      padding: 1rem;
      background: #ebf8ff;
      border-left: 4px solid #3182ce;
      border-radius: 8px;
      display: none;
      line-height: 1.8;
      color: #2d3748;
    }

    #eventResult h3 { margin-bottom: 0.5rem; color: #2b6cb0; }
  </style>
</head>
<body>
  <div class="card">
    <h2>📅 Book an Event</h2>

    <label for="eventType">Event Type</label>
    <select id="eventType">
      <option value="">— Select type —</option>
      <option value="conference">Conference ($150/hr)</option>
      <option value="wedding">Wedding ($300/hr)</option>
      <option value="birthday">Birthday ($100/hr)</option>
      <option value="corporate">Corporate ($200/hr)</option>
      <option value="concert">Concert ($250/hr)</option>
    </select>

    <label for="eventDate">Event Date</label>
    <input type="date" id="eventDate" />

    <label for="eventHours">Duration (hours)</label>
    <input type="number" id="eventHours" min="1" placeholder="e.g. 4" />

    <button id="bookBtn" onclick="bookEvent()">Book Now</button>

    <div id="eventResult"></div>
  </div>

  <script>
    async function bookEvent() {
      const eventType = document.getElementById('eventType').value;
      const eventDate = document.getElementById('eventDate').value;
      const hours     = Number(document.getElementById('eventHours').value);

      if (!eventType || !eventDate || !hours) {
        alert('Please fill all event details');
        return;
      }

      const btn = document.getElementById('bookBtn');
      btn.disabled    = true;
      btn.textContent = 'Booking...';

      try {
        const response = await fetch('/api/book-event', {
          method:  'POST',
          headers: { 'Content-Type': 'application/json' },
          body:    JSON.stringify({ eventType, eventDate, hours })
        });

        const data = await response.json();

        if (!response.ok) {
          alert(data.error);
          return;
        }

        const resultDiv = document.getElementById('eventResult');
        resultDiv.style.display = 'block';
        resultDiv.innerHTML = \`
          <h3>\${data.message}</h3>
          <strong>Booking ID:</strong> \${data.booking.id}<br>
          <strong>Event:</strong>      \${data.booking.event}<br>
          <strong>Date:</strong>       \${data.booking.date}<br>
          <strong>Duration:</strong>   \${data.booking.duration}<br>
          <strong>Rate:</strong>       \${data.booking.ratePerHour}<br>
          <strong>Total Cost:</strong> \${data.booking.totalCost}
        \`;
      } catch (error) {
        console.error('Booking failed:', error);
        alert('Network error — please try again.');
      } finally {
        btn.disabled    = false;
        btn.textContent = 'Book Now';
      }
    }
  </script>
</body>
</html>`);
});

// ─── API: POST /api/book-event ───────────────────────────────────
app.post('/api/book-event', (req, res) => {
  const { eventType, eventDate, hours } = req.body;

  if (!eventType || !eventDate || !hours) {
    return res.status(400).json({ error: 'Missing required fields: eventType, eventDate, hours.' });
  }

  if (!EVENT_PRICING[eventType]) {
    return res.status(400).json({
      error: `Unknown event type: "${eventType}". Valid types: ${Object.keys(EVENT_PRICING).join(', ')}.`
    });
  }

  if (typeof hours !== 'number' || hours <= 0) {
    return res.status(400).json({ error: 'Hours must be a positive number.' });
  }

  const ratePerHour = EVENT_PRICING[eventType];
  const totalCost   = ratePerHour * hours;

  res.status(200).json({
    message: '🎉 Booking confirmed!',
    booking: {
      id:          `BK-${Date.now()}`,
      event:       eventType.charAt(0).toUpperCase() + eventType.slice(1),
      date:        new Date(eventDate).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }),
      duration:    `${hours} hour${hours !== 1 ? 's' : ''}`,
      ratePerHour: `$${ratePerHour}/hr`,
      totalCost:   `$${totalCost.toLocaleString()}`,
    }
  });
});

// ─── Start Server ────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});

